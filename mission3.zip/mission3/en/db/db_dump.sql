-- MySQL dump 10.13  Distrib 8.0.26, for macos11.3 (x86_64)
--
-- Host: 34.133.50.179    Database: dbpharma
-- ------------------------------------------------------
-- Server version	5.7.34-google

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `drug_name` varchar(200) NOT NULL,
  `trade_names` varchar(200) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `drug_class` varchar(200) DEFAULT NULL,
  `inventory` varchar(200) DEFAULT NULL,
  `pdf` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (2,'Aspirin','Value Pharma','Aspirin','Analgesics - NonNarcotic','192','739b2b94-0d2f-4a79-8d78-4bb614eca2a0_aspirin.pdf'),(3,'Acetaminophen','Mapap','Analgesics - NonNarcotic','Analgesics - NonNarcotic','838','18f89a72-71df-4f9f-b9cb-e1092224b92d_acetaminophen.pdf'),(4,'Acetaminophen','Arthiris Pain','Analgesics - NonNarcotic','Analgesics - NonNarcotic','848','253850bc-ba93-4932-9419-fa8e4b9d4d8c_acetaminophen.pdf'),(5,'Amoxil','SmithKime Beecham','Antibiotic','Antibiotic','292','30a59c9a-50e5-42d0-b4d1-c1988cf1ef68_amoxil.pdf'),(6,'Ipuprofen','Advil','Analgesics - NonNarcotic','Analgesics - NonNarcotic','928','50ff374f-267c-4c7e-bb35-e5d8b735494f_ipuprofen.pdf'),(7,'Acetaminophen','Tylenol','Analgesics - NonNarcotic','Analgesics - NonNarcotic','212','9ffdf2d1-799e-432d-b217-3ed7329761f3_acetaminophen.pdf'),(8,'Belladonna Alkaloids with Phenobarbital','Donnatal Tablet','Endocrine and Metabolic Agents- Misc.  (Bisphosphonate) ','Endocrine and Metabolic Agents- Misc.  (Bisphosphonate) ','2i2','bbed3bcb-fd76-4636-bd51-47a9bfc4a3cc_phenobarbital.pdf'),(9,'Donepezil HCI','Aricept','Aricept','Analgesics - Anti-inflammatory','393','6d20d634-16b9-4343-9e78-ff632629e11a_hci.pdf'),(10,'glimepiride','Amaryl','Amaryl','Antiparkinson Agents (NMDA receptor antagonist)','223','0737243e-d820-4e28-b57c-89056dee2f9b_glimepiride.pdf'),(11,'Loratadine OTC tablet','Claritin OTC','Analgesics - NonNarcotic','Analgesics - NonNarcotic','689','78083922-1093-455c-bc64-36005f27986c_tablet.pdf');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;
