CREATE TABLE `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `drug_name` varchar(200) NOT NULL,
  `trade_names` varchar(200) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `drug_class` varchar(200) DEFAULT NULL,
  `inventory` varchar(200) DEFAULT NULL,
  `pdf` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
