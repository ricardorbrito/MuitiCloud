from flask_wtf import FlaskForm
from wtforms import StringField, SelectField
from flask_wtf.file import FileField
from wtforms.validators import DataRequired, Length


class ProductForm(FlaskForm):
    drug_name = StringField('Drug Name', validators=[DataRequired(), Length(min=-1, max=200, message='Field should not have more than 200 characters.')])
    trade_names = StringField('Trade Names', validators=[DataRequired(), Length(min=-1, max=200, message='Field should not have more than 200 characters.')])
    description = StringField('Description', validators=[Length(min=-1, max=200, message='Field should not have more than 100 characters.')])
    drug_class = StringField('Drug Class', validators=[Length(min=-1, max=200, message='Field should not have more than 200 characters.')])
    inventory = StringField('Inventory', validators=[Length(min=-1, max=200, message='Field should not have more than 20 characters.')])
    pdf = FileField('Drug Label')
    