from flask import Flask
from flask_sqlalchemy import SQLAlchemy
import os

# Database Info

DB_HOST_NAME = os.environ.get('DB_HOST_NAME')
DB_USER = os.environ.get('DB_USER')
DB_PASSWORD = os.environ.get('DB_PASSWORD')
DB_NAME = os.environ.get('DB_NAME')
DB_PORT = os.environ.get('DB_PORT')


app = Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://{}:{}@{}:{}/{}'.format(DB_USER,DB_PASSWORD,DB_HOST_NAME,DB_PORT,DB_NAME)
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

class Product(db.Model):

    __tablename__ = 'products'

    id = db.Column(db.Integer, primary_key=True)
    drug_name = db.Column(db.String(200), nullable=False)
    trade_names = db.Column(db.String(200), nullable=True)
    description = db.Column(db.String(200), nullable=True, unique=False)
    drug_class = db.Column(db.String(200), nullable=True, unique=False)
    inventory = db.Column(db.String(200), nullable=True, unique=False)
    pdf = db.Column(db.String(200), nullable=True, unique=False)

    def __repr__(self):
        return '<Products %r>' % self.name
