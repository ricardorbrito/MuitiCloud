from flask_wtf import FlaskForm
from wtforms import StringField, SelectField
from flask_wtf.file import FileField
from wtforms.validators import DataRequired, Length


class ProductForm(FlaskForm):
    drug_name = StringField('Nome da Composição', validators=[DataRequired(), Length(min=-1, max=200, message='Campo não deve ter mais do que 200 caracteres.')])
    trade_names = StringField('Nome Comercial', validators=[DataRequired(), Length(min=-1, max=200, message='Campo não deve ter mais do que 200 caracteres.')])
    description = StringField('Descrição', validators=[Length(min=-1, max=200, message='Campo não deve ter mais do que 200 caracteres.')])
    drug_class = StringField('Classe', validators=[Length(min=-1, max=200, message='Campo não deve ter mais do que 200 caracteres.')])
    inventory = StringField('Inventário', validators=[Length(min=-1, max=200, message='Campo não deve ter mais do que 200 caracteres.')])
    pdf = FileField('Etiqueta')
    