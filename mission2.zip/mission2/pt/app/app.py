from flask import Flask, redirect, url_for, render_template, request, flash
from models import db, Product
from forms import ProductForm
import os
from werkzeug.utils import secure_filename

from helpers import upload_file, generate_unique_filename, allowed_file, create_presigned_url

from config import AWS_BUCKET, DB_HOST_NAME, DB_USER, DB_PASSWORD, DB_NAME, DB_PORT

# Flask
app = Flask(__name__)
app.config['SECRET_KEY'] = os.urandom(32)
app.config['DEBUG'] = False


app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://{}:{}@{}:{}/{}'.format(DB_USER,DB_PASSWORD,DB_HOST_NAME,DB_PORT,DB_NAME)
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db.init_app(app)


@app.route("/")
def index():
    '''
    Home page
    '''
    #return redirect(url_for('products'))
    return render_template('web/home.html')


@app.route("/new_product", methods=('GET', 'POST'))
def new_product():
    '''
    Create new product
    '''
    form = ProductForm()
    if form.validate_on_submit():
        my_product = Product()
        form.populate_obj(my_product)

        file_to_upload = request.files['pdf']
        final_file_name = generate_unique_filename(my_product.drug_name)
        my_product.pdf = final_file_name

        db.session.add(my_product)


        if not file_to_upload:
            flash('Arquivo não selecionado.','danger')
            return render_template('web/new_product.html', form=form)
        
        if file_to_upload and not allowed_file(file_to_upload.filename):
            flash('Formato inválido. Apenas PDFs permitidos.','warning')
            return render_template('web/new_product.html', form=form)


        try:
            filename = secure_filename(file_to_upload.filename)
            file_to_upload.save(filename)
            upload_file(filename,AWS_BUCKET,final_file_name)
            os.remove(filename)
            db.session.commit()
            # User info
            flash('Produto adicionado com sucesso.', 'success')
            return redirect(url_for('products'))
        except Exception as error:
            print(error)
            db.session.rollback()
            flash('Erro ao tentar adicionar o produto.', 'danger')

    return render_template('web/new_product.html', form=form)


@app.route("/edit_product/<id>", methods=('GET', 'POST'))
def edit_product(id):
    '''
    Edit product

    :param id: Id from product
    '''
    my_product = Product.query.filter_by(id=id).first()
    form = ProductForm(obj=my_product)



    if form.validate_on_submit():
        try:
            # Update product

            if not form.pdf.data:
                form.pdf.data = my_product.pdf
                form.populate_obj(my_product)
            else:
                file_to_upload = request.files['pdf']

                if file_to_upload and not allowed_file(file_to_upload.filename):
                    flash('Formato inválido. Apenas PDFs permitidos.','warning')
                    return render_template('web/new_product.html', form=form)
                
                final_file_name = generate_unique_filename(my_product.drug_name)
                filename = secure_filename(file_to_upload.filename)
                file_to_upload.save(filename)
                upload_file(filename,AWS_BUCKET,final_file_name)
                os.remove(filename)

                form.populate_obj(my_product)
                my_product.pdf = final_file_name

            db.session.add(my_product)
            db.session.commit()

            # User info
            flash('Atualizado com sucesso.', 'success')
        except Exception as error:
            print(error)
            db.session.rollback()
            flash('Erro ao atualizar.', 'danger')
    return render_template(
        'web/edit_product.html',
        form=form)


@app.route("/products")
def products():
    '''
    Show alls products
    '''
    products = Product.query.order_by(Product.drug_name).all()
    return render_template('web/products.html', products=products)


@app.route("/search")
def search():
    '''
    Search
    '''
    name_search = request.args.get('name')
    all_products = Product.query.filter(
        Product.drug_name.contains(name_search)
        ).order_by(Product.drug_name).all()
    return render_template('web/products.html', products=all_products)


@app.route("/products/delete", methods=('POST',))
def products_delete():
    '''
    Delete product
    '''
    try:
        product = Product.query.filter_by(id=request.form['id']).first()
        db.session.delete(product)
        db.session.commit()
        flash('Deletado com sucesso.', 'danger')
    except:
        db.session.rollback()
        flash('Erro ao deletar.', 'danger')

    return redirect(url_for('products'))

@app.route("/products/pdf/<id>", methods=('GET',))
def products_pdf(id):
    '''
    View signed form

    :param id: Id from pdf
    '''
    my_product = Product.query.filter_by(id=id).first()
    pdf_form_pre_signed_url = create_presigned_url(AWS_BUCKET,my_product.pdf)

    return redirect(pdf_form_pre_signed_url)


if __name__ == "__main__":
    app.run(host="0.0.0.0")
